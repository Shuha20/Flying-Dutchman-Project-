// language dictionary and function
var language = {
    "eng":   // English
    [{
        "home": "Home",
        "menu": "Menu",
        "order": "Order",
        "login": "Login",
        "account": "Account",
        "manage": "Manage",
        "drink": "Drink",
        "filter": "Filter",
        "min_alc": "Min Alc.",
        "max_alc": "Max Alc.",
        "confirm": "Confirm",
        "cart": "Cart",
        "undo": "Undo",
        "redo": "Redo",
        "add_to_order": "Add to order",
        "username": "Username",
        "password": "Password",
        "wrong_message": "Wrong username or password!",
        "language": "Language",
        "no_order": "No order!",
        "pay": "Pay",
        "logout": "Log out",
        "intro": "<p class=\"welcome\">Welcome to Flying Dutchman</p>"+
                "<p>Opening hour : 16:00 ~ 3:00 Monday-Sunday</p>"+
                "<p>Address : Uppsala</p>"+
                "<p>Email : info@pub.se</p>"+
                "<p>Phone : 018-111111</p>"
    }],
    "swe":  // Swedish
    [{
        "home": "Hem",
        "menu": "Meny",
        "order": "Beställa",
        "login": "Logga in",
        "account": "Konto",
        "manage": "Hentera",
        "drink": "Dryck",
        "filter": "Filtrera",
        "min_alc": "Min Alkoholhalt",
        "max_alc": "Max Alkoholhalt",
        "confirm": "Bekräfta",
        "cart": "Vagn",
        "undo": "Ångra",
        "redo": "Göra om",
        "add_to_order": "Lägg till beställning",
        "username": "Användarnamn",
        "password": "Lösenord",
        "wrong_message": "Fel användarnamn eller lösenord!",
        "language": "Språk",
        "no_order": "Ingen order!",
        "pay": "Betala",
        "logout": "Logga ut",
        "intro": "<p class=\"welcome\">Välkommen till Flying Dutchman</p>"+
                "<p>ÖPPETTIDER : 16:00 ~ 3:00 Måndag-söndag</p>"+
                "<p>Adress : Uppsala</p>"+
                "<p>E-post : info@pub.se</p>"+
                "<p>Tel : 018-111111</p>"
    }],
    "chi":  // Chinese
    [{
        "home": "首頁",
        "menu": "菜單",
        "order": "訂單",
        "login": "登入",
        "account": "帳戶",
        "manage": "管理",
        "drink": "飲料",
        "filter": "篩選",
        "min_alc": "最低酒精濃度",
        "max_alc": "最高酒精濃度",
        "confirm": "確認",
        "cart": "購物車",
        "undo": "復原",
        "redo": "取消復原",
        "add_to_order": "加入購物車",
        "username": "使用者名稱",
        "password": "密碼",
        "wrong_message": "使用者名稱或密碼錯誤！",
        "language": "語言",
        "no_order": "沒有點餐",
        "pay": "付款",
        "logout": "登出",
        "intro": "<p class=\"welcome\">歡迎來到 Flying Dutchman</p>"+
                "<p>營業時間 : 16:00 ~ 3:00 週一-週日</p>"+
                "<p>地址 : Uppsala</p>"+
                "<p>電子郵件 : info@pub.se</p>"+
                "<p>電話 : 018-111111</p>"
    }]
}

var lang = [];

function switch_lang(text) {
    lang = [];
    if(text == 'eng') {
        for (var i=0; i<language.eng.length; i++) {
            lang.push([language.eng[i]]);
        }
    }
    else if(text == 'swe') {
        for (var i=0; i<language.swe.length; i++) {
            lang.push([language.swe[i]]);
        }
    }
    else {
        for (var i=0; i<language.chi.length; i++) {
            lang.push([language.chi[i]]);
        }        
    }
    lang = lang[0][0];
    console.log(lang);
    // get each element's id and change inner text
    document.getElementById("list_home").innerHTML = lang.home;
    document.getElementById("list_menu").innerHTML = lang.menu;
    document.getElementById("list_order").innerHTML = lang.order;
    document.getElementById("list_language").innerHTML = lang.language;
    document.getElementById("filter_button").innerHTML = lang.filter;
    document.getElementById("min_alc_label").innerHTML = lang.min_alc;
    document.getElementById("max_alc_label").innerHTML = lang.max_alc;
    document.getElementById("confirm_button").innerHTML = lang.confirm;
    document.getElementById("cart_button").innerHTML = lang.cart;
    document.getElementById("undo").innerHTML = lang.undo;
    document.getElementById("redo").innerHTML = lang.redo;
    document.getElementById("pay_button").innerHTML = lang.pay;
    document.getElementById("home_text").innerHTML = lang.intro;
    if(document.getElementById("login_alert")) {
        document.getElementById("login_alert").innerHTML = lang.wrong_message;
    }
    if(document.getElementById("username")) {
        document.getElementById("username").setAttribute("placeholder", lang.username);
    }
    if(document.getElementById("password")) {
        document.getElementById("password").setAttribute("placeholder", lang.password);
    }
    if(document.getElementById("login_button")) {
        document.getElementById("login_button").innerHTML = lang.login;
    }
    if(document.getElementById("list_login")) {
        document.getElementById("list_login").innerHTML = lang.login;
    }
    if(document.getElementById("list_account")) {
        document.getElementById("list_account").innerHTML = lang.account;
    }
    if(document.getElementById("cart_text")) {
        document.getElementById("cart_text").innerHTML = lang.no_order;
    }
    if(document.getElementById("logout")) {
        document.getElementById("logout").innerHTML = lang.logout;
    }
}
