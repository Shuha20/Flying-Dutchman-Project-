// functions for menu page
// Menu list function
function Show_menu(min, max) {
    var list_str = "";
    var beverages = allBeverages().splice(0, 100);
    beverages = beverages.sort();
    for(var i=1; i<beverages.length; i+=1) {
        var index = beverages[i][0];
        var collector = find_beverages(index);
        var info = collector[0][0];
        if (percentToNumber(info.alkoholhalt)>=min && percentToNumber(info.alkoholhalt)<=max) {  // for filter
            list_str += "<div id=\""+index+"\" onclick=\"name_click("+index+")\" draggable=\"true\" ondragstart=\"drag(event)\">" + info.namn + "&nbsp &nbsp"+ info.prisinklmoms + "kr" + "</div>";
        }
    }
    document.getElementById('drink_list').innerHTML = list_str;
}

// Drag and Drop
function drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev) {
    ev.preventDefault();
    var index = ev.dataTransfer.getData("text");
    Add_to_cart(index);
    store = [];
    console.log(DB_cart);
    console.log(DB_cart_num);
}

function allowDrop(ev) {
    ev.preventDefault();
}

// show for detail of product
function name_click(i) {
    var modal = document.getElementById("myModal");
    modal.style.display = "block";
    console.log("click");
    var collector = find_beverages(i);
    var all_info = collector[0][0];
    var info = "Number: "+all_info.nr
                +"<br>Name: "+all_info.namn
                +"<br>Type: "+all_info.varugrupp
                +"<br>Price incl. VAT: "+all_info.prisinklmoms
                +"<br>Volumn ml: "+all_info.volymiml
                +"<br>Alcohol content: "+all_info.alkoholhalt
                +"<br>Supplier: "+all_info.leverantor;
    document.getElementById("drink_detail").innerHTML = info;
}

// the close button on pop up window
function span_click() {
    console.log("span click");
    var modal = document.getElementById("myModal");
    modal.style.display = "none";
}

// filter function
function filter_click() {
    var modal = document.getElementById("filter_modal");
    modal.style.display = "block";
    console.log("click filter");
}

// the close button on pop up window
function span_filter_click() {
    console.log("span click");
    var modal = document.getElementById("filter_modal");
    modal.style.display = "none";
}

function filter_confirm() {
    var min = document.getElementById("min_alc").value;
    var max = document.getElementById("max_alc").value;
    var modal = document.getElementById("filter_modal");
    modal.style.display = "none";
    Show_menu(min, max);
}

// order
var DB_cart = [];  // store beverage's index
var DB_cart_num = [];  // store beverage's number

// Cart/order function
function cart_click() {
    var modal = document.getElementById("cart_modal");
    modal.style.display = "block";
    console.log("click cart");
    Show_cart();
}

function Add_to_cart(index) {
    if(!DB_cart.includes(index)) {
        DB_cart.push(index);
        DB_cart_num.push(1);
    }
    else {
        for (var i=0; i<DB_cart.length; i++) {
            if(DB_cart[i] == index) {
                DB_cart_num[i] += 1;
            }
        }
    }
    now.push(index);
    console.log(now);
}

function Delete_from_cart(index) {
    for(var i=0; i<DB_cart.length; i+=1) {
        if(DB_cart[i] == index) {
            DB_cart_num[i] -= 1;
            if(DB_cart_num[i] == 0) {
                DB_cart.splice(i, 1);
                DB_cart_num.splice(i, 1);
            }
        }
    }
}

function Show_cart() {
    console.log(DB_cart.length);
    var modal = document.getElementById("cart_list");
    var list="";
    if(DB_cart.length != 0) {
        for(var i=0; i<DB_cart.length; i++) {
            var collector = find_beverages(DB_cart[i]);
            var info = collector[0][0];
            list += "<div id=\""+DB_cart[i]+"\" onclick=\"name_click("+DB_cart[i]+")\">"+info.namn+"&nbsp &nbsp &nbsp x"+DB_cart_num[i]+"</div>"
        }
        modal.innerHTML = list;
    }
    else {
        list = "<p id='cart_text'>"+lang.no_order+"</p>";
        modal.innerHTML = list;
    }
}

// close button on pop up window
function span_cart_click() {
    console.log("span click");
    var modal = document.getElementById("cart_modal");
    modal.style.display = "none";
}

// Order function
function Show_order() {
    var text="";
    for(var i=0; i<DB_cart.length; i++) {
        var info = find_beverages(DB_cart[i])[0][0];
        text +=  "<div id=\""+DB_cart[i]+"\"><div><p>"+info.namn+"</p></div>"+
                "<div class=\"order_text_right\">"+
                "<button onclick=\"Add_order("+DB_cart[i]+")\">+</button>"+
                "<p>"+DB_cart_num[i]+"</p>"+
                "<button onclick=\"Delete_order("+DB_cart[i]+")\">-</button>"+
                "</div></div>"
    }
    document.getElementById("order_text").innerHTML = text;
}

// add and delete button in order page
function Add_order(index) {
    index = index.toString();
    Add_to_cart(index);
    Show_order();
}

function Delete_order(index) {
    Delete_from_cart(index);
    Show_order();
}

// Undo-Redo
var now = [];  // store new action
var store = [];  // store undo action

function undo_click() {
    if(now.length != 0) {
        console.log(now);
        var index = now.pop();
        Delete_from_cart(index);
        store.push(index);
        console.log(DB_cart);
        console.log(DB_cart_num);    
    }
}

function redo_click() {
    if(store.length != 0) {
        var index = store.pop();
        Add_to_cart(index);
        console.log(DB_cart);
        console.log(DB_cart_num);    
    }
}
