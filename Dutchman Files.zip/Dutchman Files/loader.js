// =====================================================================================================
// SOme sample API functions for the Flying Dutchman data base.
// =====================================================================================================
// Author: Lars Oestreicher, 2018
//
// Adapted from a mySQL data base.
//
// We use (global) variables to store the data. This is not generally advisable, but has the
// advantage that the data is easy to access through simple APIs. Also, when storing as local storage,
// all data is stored as strings, which might be adding some complexity.
//

// functions for general, login, and account page
// initial page
function Start_page() {
    switch_lang('eng');
    Open_Home();
}

// Change div
function Open_Home() {
    hidden_div();
    document.getElementById("home_div").style.display = 'block';
    document.getElementById("list_home").style.color = '#5FC5FF';
}

function Open_Menu() {
    hidden_div();
    document.getElementById("menu_div").style.display = 'block';
    document.getElementById("list_menu").style.color = '#5FC5FF';
    Show_menu(0, 100);
}

function Open_Order() {
    hidden_div();
    document.getElementById("order_div").style.display = 'block';
    document.getElementById("list_order").style.color = '#5FC5FF';
    Show_order();
}

function Open_Login() {
    hidden_div();
    document.getElementById("login_div").style.display = 'block';
    document.getElementById("list_login").style.color = '#5FC5FF';
}

function Open_Account() {
    hidden_div();
    document.getElementById("login_div").style.display = 'block';
    document.getElementById("list_account").style.color = '#5FC5FF';
    Show_user();
}

function Open_Manage() {
    hidden_div();
    document.getElementById("manage_div").style.display = 'block';
    document.getElementById("list_account").style.color = '#5FC5FF';
}

function Open_Reservation() {
    hidden_div();
    document.getElementById("reservation_div").style.display = 'block';
    document.getElementById("list_account").style.color = '#5FC5FF';
}

function hidden_div() {
    // div hidden
    var w = document.getElementById("content");
    if (w.hasChildNodes()) {
        var children = w.childNodes;
        for (var i=0; i<children.length; i+=1) {
            if(typeof children[i].id !== "undefined") {
                console.log(children[i].id);
                document.getElementById(children[i].id).style.display = 'none';
            }
        }
    }
    // list color to white
    var w = document.getElementById("list");
    if (w.hasChildNodes()) {
        var children = w.childNodes;
        for(var i=0; i<children.length; i+=1) {
            if(children[i].childNodes != 0) {
                var cc = children[i].childNodes
                for(var j=0; j<cc.length; j+=1) {
                    if(typeof cc[j].id !== "undefined" && cc[j].id.includes("list")) {
                        console.log(cc[j].id);
                        document.getElementById(cc[j].id).style.color = 'white';    
                    }
                }
            }
        }
    }
}

// login page function

var User = "";

function Login() {
    // get username and password from input
    var x = document.getElementById("login");
    var text = "";
    var i;
    for(i=0; i<x.length; i+=1) {
        text += x.elements[i].value;
    }
    var username = x.elements[0].value;
    var paswd = x.elements[1].value;
    var user_id = 0;
    var cre = 0;
    for (i = 0; i < DB.users.length; i++) {
        if (DB.users[i].username == username) {
            if(DB.users[i].password == paswd) {
                user_id = DB.users[i].user_id;
                cre = DB.users[i].credentials;
                User = username;
                console.log(User);
            }
        };
    };
    if (user_id!=0) {    // login success
        if(cre == 3) {    // login as VIP
            window.open('VIP_page.html?UserName='+User, '_self');
        }
        else {    // login as staff
            window.open('Staff_page.html', '_self');
        }
    }
    else {    // login fail
        document.getElementById("login_alert").style.display = "block";
    }
}

function Log_out() {
    window.open('index.html', '_self');
}

// VIP Account page function
function userDetails() {
    console.log(User);
    var userCollect = [];
    var userID;
    var userIndex;
    var account;

    // First we find the user ID of the selected user. We also save the index number for the record in the JSON
    // structure.
    //
    for (i = 0; i < DB.users.length; i++) {
        if (DB.users[i].username == User) {
            userID = DB.users[i].user_id;
            userIndex = i;
        };
    };

    // We get the current account status from another table in the database, account. We store this in
    // a variable here for convenience.
    //
    for (i = 0; i < DB.account.length; i++) {
        if (DB.account[i].user_id == userID) {
            account = DB.account[i].creditSEK;
        }
    };

    // This is the way to add the details you want from the db into your own data structure.
    // If you want to change the details, then just add or remove items accordingly below.
    console.log(userIndex);
    userCollect.push(
        DB.users[userIndex].user_id,
        DB.users[userIndex].username,
        DB.users[userIndex].first_name,
        DB.users[userIndex].last_name,
        DB.users[userIndex].email,

        account
    );

    return userCollect;
}

// add user's information in the VIP account page
function Show_user() {
    var v = window.location.search;
    if(v!=null) {
        v = v.split('=');
        console.log(v[1]);
        User = v[1];
    }
    usercollect = userDetails();
    console.log(usercollect);
    var text = "";
    text = "<p>Username : "+usercollect[1]+"</p>"+
            "<p>First_name : "+usercollect[2]+"</p>"+
            "<p>Last_name : "+usercollect[3]+"</p>"+
            "<p>E-mail : "+usercollect[4]+"</p>"+
            "<p>Account : "+usercollect[5]+"</p>";
    console.log(text);
    document.getElementById("user_detail").innerHTML = text;
}

// other function
// find specific product based on index
function find_beverages(index) {
    var collector = [];
    for (i=0; i<DB2.spirits.length; i++) {
        if (index == DB2.spirits[i].nr) {
            collector.push([DB2.spirits[i]]);         
        }
    }
    return collector;
}

// get all products
function allBeverages() {
    // Using a local variable to collect the items.
    var collector = [];

    // The DB is stored in the variable DB2, with "spirits" as key element. If you need to select only certain
    // items, you may introduce filter functions in the loop... see the template within comments.
    //
    for (i = 0; i < DB2.spirits.length; i++) {
        collector.push([DB2.spirits[i].nr, DB2.spirits[i].namn, DB2.spirits[i].varugrupp]);
    };

    return collector;
}

// =====================================================================================================
// Convenience function to change "xx%" into the percentage in whole numbers (non-strings).
//
function percentToNumber(percentStr) {
    return Number(percentStr.slice(0,-1));
}

// =====================================================================================================
// =====================================================================================================
// END OF FILE
// =====================================================================================================
// =====================================================================================================


